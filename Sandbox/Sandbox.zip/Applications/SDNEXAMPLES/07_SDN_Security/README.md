# Lab 07 : SDN Security

## Objective

In this series of exercises, you will learn to use User Access Control lists (think Firewall\Network Security Groups), Egress Metering for VIrtual Networks, Encrypting Virtual Subnets, 

# Lab 07.01 User Access Control Lists (ACLs)

## Exercise 01: Create and apply ACL to a Network Interface



## Exercise 02: Remove an ACL from a Network Interface

## Exercise 03: Create and apply ACL to a Virtual Network

## Exercise 04: Remove an ACL from a Virtual Subnet



# Lab 07.02 Egress Metering in Virtual Network

# Lab 07.03 Configure Encryption for a Virtual Subnet

# Lab 07.04 Update the Network Controller Server Certificate - TBD
